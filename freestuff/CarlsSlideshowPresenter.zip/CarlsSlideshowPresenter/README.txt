October 12, 2016

Carl's Slideshow Presenter

This is a REBOL "powerpoint"-like program for making basic slideshows.
It is a good example of a small program that does one thing well,
and also a good example of how REBOL should be written since it was
written by the author of REBOL himself.

The program was obtained from:

http://www.rebol.com/notes/devcon07-carl.zip

and also was documented by Nick Antonaccio here:

http://business-programming.com/business_programming.html#section-8.4 

This version exists because I had to make a quick presentation and it
was faster to figure out how to use this program than it would have
been to beat my head on Powerpoint.

The program is packed in a zip file because it includes a picture that
is used as a background image and a text file that shows the format of
the file used as the source of a presentation.

It seems that this program is based on the same philosophy as the
"makedoc" program for producing REBOL documentation, which Carl also
wrote.  The idea is that documentation can be written in a plain text
file, and with some well-designed minimal markup, can be processed into
other formats, like an html file or a slideshow.  With the markup being
"minimal," the documentation can be read in its "raw" form, that is, the
original text file.  In other words, there is just enough markup to
allow the writing of a formatting program, but not so much that it makes
the raw form unreadable.  In the makedoc format, and to some extent here,
white space and blank lines are part of the markup, which forces a person
to make a document at least somewhat readable in raw form.

The source of a slideshow is a text file in a particular format.  
The documentation file included here shows that format.  You can see how
it works by running the program and, at the initial file request dialog,
selecting the included documentation file.  Use the up-arrow and down-arrow
keys to move through the presentation.  After you see how it works,
make your own file and try it.  

The documentation file documents what I could discover by trial and error.
There could be other features I missed, but not many because the program
is not that complicated.  Enough of the features are discoverd and
documented to make the program useful.  If you need other features that
I missed or are not included in the program, you should consider if you
are making a presentation to present information or to present the fancy
features of the presentation program.

One thing I did not figure out is why, when you run the program, it does
not initially display the first section, but starts with the second.
You can get to the first by backing up from the second with the up-arrow.
There also seems to be an "=intro" tag which one would think marks an
introduction, but I could not figure out how to use it since putting it
in various places had no effect that I observed.  

