REBOL [
	Title: "Slideshow Presenter"
	Author: "Carl Sassenrath"
	Version: 3.0.3
	Note: "Panel diagrams mode not tested, probably broken now"
        History: {This program was obtained from a presentation by Carl 
at what seemed to be the 2007 developer conference.  I downloaded it 
from somewhere and can't remember where.  I needed a presentation program
so I figured out how to use this well enough for my needs, made a couple
trivial modifications (title and background picture), and used it. 
Since there is no license on it, I present it with some documentation so
others may use it.  I called it CASPRE for Carl's Slideshow Presenter.
This is an example, one would think, of REBOL as it should be written.
As I did this, I discovered that Nick Antonaccio had gone through the
same exercise over a year previously, and documented it here:
http://business-programming.com/business_programming.html#section-8.4 
from the original located here:
http://www.rebol.com/notes/devcon07-carl.zip
Steven White.}
]

file:       system/script/args
if not file? file [file: request-file/only]
if not file [
    alert "No file requested"
    quit
]
title-line: "Carl's Slideshow Presenter"  ;; originally was hard-coded title
diags:      %diags.r
;;back-image: %chiptower.jpg  ;; Original background 
back-image: %BackgroundPicture.jpg  ;; Supply your own if you like 
author-mode: off
time-need:  1:00

;-- Configuration ------------------------------------------------------------

page-size: system/view/screen-face/size
;page-size: 800x600
;page-size: 1024x800
;page-size: 740x480
big-size:  page-size/x > 1000
sect-size: page-size/x / 4 - 40
text-size: (round/to page-size/y / 32 4) - 1 ;pick [28 20] big-size
margin: round page-size/x / 10
h2-size: as-pair page-size/x - margin - 30 text-size * 2
h3-size: h2-size - (text-size / 2)
origin: page-size / 11
def-in: round page-size/x / 7
spacing: page-size / 100x200

;-- Styles -------------------------------------------------------------------

back-image: load back-image

stylize/master [

	vh2: vh2 h2-size left top font [
		size: text-size + 6
		name: "arial black"
		style: [underline]
		color: 240.220.60
		shadow: 3x3
	]

	vh3: vh2 h3-size left middle font [
		color: white
		style: [bold] ; underline]
		size: text-size
		name: "arial"
	]
	para [origin: 10x2]
	effect [merge gradmul 96.96.96 128.128.128]

	txt: vtext page-size/x - margin - 50 font [
		style: 'bold
		size: text-size
		shadow: 2x2
	]

	txtb: txt page-size/x - margin - 50 font [
		color: sky + 30
	]

	txti: txt italic white effect [merge colorize red]

	code: tt page-size/x - (margin * 2) - 50
		black snow edge [size: 2x2 color: gold]
		;snow coal edge [size: 2x2 color: gray]
		font [
		size: round (text-size * .8)
		style: 'bold
		colors: [0.0.0 0.0.80]
	] as-is para [origin: margin: 12x8]
]

bullet: to-image make face [
	size: text-size / 2 - 1 * 1x1
	color: 160.0.0
	edge: make edge [color: black size: 0x0]
	effect: [oval gradmul 1x1 255.255.255 0.0.0 oval]
]
shift-bullet: text-size - bullet/size/y * 0x1

;bold: make face/font [name: "Arial Black" size: 480]
;scale: page-size/x / 800 / 17

backdrop: layout [
	size page-size
	across
	at 0x15 box as-pair page-size/x text-size * 2
		edge [size: 0x2 color: gold] 
		effect [merge grid navy gradmul 200.120.100 128.128.128]
	origin 10x20
	banner font-size text-size + 4 italic title-line white ;font-color silver
	return
]

backdrop/image: back-image
backdrop/effect: [gradmul 1x-1 50.50.90 100.120.140 fit]
backdrop: to-image backdrop

end-mark: make face [
	offset: page-size * 0x1 + 40x-20 size: 140x3 ; -140x80
	effect: [gradient maroon green]
]

pan-mark: make face [
	offset: page-size * 0x1 + 40x-20 size: 140x3
	effect: [gradient maroon purple]
]

;-- Scanner ------------------------------------------------------------------


*scanner*: context [

;-- Variables:
text: none
part: none
code: none
title: none
out: [] ; holds output block

;-- Emitters:
emit: func ['word data] [
	if block? word [word: do word]
	if string? data [trim/tail data]
	repend out [word data]
]

emit-section: func [num] [
	emit [to-word join "sect" num] text
	title: true
]

;--- Text Format Language:
rules: [
	[to "^/=start" skip to newline (author-mode: true) | none]
	some parts
]
parts: [
	;here: (print here)
	newline |

	spaces

	;--Document sections:
	"===" text-line (emit-section 1) |
	"---" text-line (emit-section 2) |
	"###" to end (emit end none) |

	;--Special common notations:
	"***" para opt newline (emit bullet3 part) |
	"**" para opt newline (emit bullet2 part) |
	"*" para opt newline (emit bullet1 part) |
	":" define opt newline (emit define reduce [text part]) |
        "#" para opt newline (emit enum part) |
	"!" para (emit txti part)|
	"[" example (emit code detab code) | ; trim/auto
	";" thru newline |  ; comment
	";===" to "===" |

	"==" output (emit output head insert code "  ") |
	"=image" file (emit image text) |
	"=all" (emit all true) |
	"=intro" (emit intro true) |
	"=diagram" some-chars (emit diagram text) |
	"=pad" num (emit pad num-n) |
	"=skip" num (clear back back tail out) num-n [to "===" thru newline] |
	"=" some-chars | ; ignore unknown options


	;--Defaults:
	para (emit para part) |
	skip
]

space: charset " ^-"
nochar: charset " ^-^/"
chars: complement nochar
spaces: [any space]
some-chars: [some space copy text some chars]
text-line: [copy text thru newline]
;par:       [copy part some chars newline]
para: [copy part some [chars thru newline]]
;example:   [copy code some indented] ; | some newline indented]]
example:   [thru newline copy code to "^/]" skip thru newline]
indented:  [some space chars thru newline]
output:    [copy code indented any ["==" copy text indented (append code head insert text "  ")]] ; compensate for ==
define:    [copy text to " -" 2 skip any space para]
file:      [spaces copy text some chars thru newline (text: to-file trim text)]
num:       [spaces copy text any chars (num-n: either text [to-integer text][1])]
num-n: 0

;-- Export function to scan doc. Returns format block.
set 'scan-doc func [str] [
	clear out
	parse/all detab str rules
	copy out
]
]

;-- Load it up ---------------------------------------------------------------

doc-text: read file
if find doc-text "=author" [author-mode: on]
doc: scan-doc doc-text
;?? doc halt
;do diags ;;; NASTY!

;-- Globals ------------------------------------------------------------------

this-page: doc ; points to current page position
title:   select doc 'title
options: select doc 'options
time-left: 1.0
time-start: now/time
back-flag: false

;-- Helpers ------------------------------------------------------------------

title-of: :second
next-page: does [this-page: any [find next this-page 'sect1 this-page]]
back-page: does [this-page: any [find/reverse back this-page 'sect1 this-page]]
limg: :load-image
load-image: func [file][
	either exists? file [limg file][make image! reduce [page-size / 3 200.0.0]]
]

;-- Page Builder -------------------------------------------------------------

build-page: has [page out emit bull count] [

	at-once: author-mode
	intro: false
	in-sect: false
	count: 0

	; Slide title line and indentation:
	out: compose [
		across space spacing
		at (origin)
;		vh2 (title-of this-page) return
;		indent margin guide
	]
	emit: func [blk] [append out compose blk]
	bull: func [depth] [
		emit [pad (20x0 * 2 * depth + shift-bullet)]
		emit [image bullet effect [key 0.0.0]]
		emit [pad (-8x0 - shift-bullet)]
	]

	foreach [type data] this-page [
		switch type [
			sect1 [
				if in-sect [break]
				in-sect: true
				emit [
					vh2 (data) return
					indent (margin) guide
				]
			]
			sect2 [emit [pad 0x4 * spacing vh3 (data) return]]
			para [emit [txt (data) return]]
			code [emit [pad to-integer margin / 3 code (trim/auto data) return]]
			bullet1 [bull 1 emit [txtb (data) return]]
			bullet2 [bull 2 emit [txtb (data) return]]
			enum [emit [txtb (join count: count + 1 [". " data]) return]]
			pad [emit [pad (data * text-size * 0x1)]]
			txti [emit [txti (data) return]]
			define [emit [pad 30 txt def-in no-wrap (data/1) txtb (data/2) return]]
			diagram [
				type: layout/tight blk: get to-word data
				emit [
					pad (as-pair margin 30)
					;panel (type/size) [(blk)]
					return
				]
			]
			image [
				data: load-image data
				emit [
					pad (as-pair page-size/x - data/size/x / 2 - margin text-size)
					image (data)
					return
				]
			]
			intro [
				intro: true
				at-once: true
			]
			all [at-once: true]
		]
	]
	out: layout/tight out
	offs: 100x100
	if intro [
		foreach face out/pane [
			if face/style = 'txt [offs: 110x120]
			face/offset: face/offset + offs
		]
	]
	out/pane
]

;-- Show page:
show-page: func [out] [
	; Do we step through items one at a time?
	either any [at-once back-flag] [
		items: []
	][
		items: copy next out
		clear next out
	]
	screen/pane: out
	if at-once [show-end-mark]
	show screen
	back-flag: false
]

pan: []

show-end-mark: does [
	time-used: now/time - time-start
	either time-need - time-used <= 0:00 [
		end-mark/effect/3: red
		end-mark/size/x: 140
	][
		end-mark/size/x: (to-decimal (time-need - time-used) / to-integer (time-need)) * 140
	]
	append screen/pane end-mark
]

;-- Traverse pages:
next-item: does [

	if not empty? pan [
		append panel pan/1
		remove pan
		if empty? pan [
			append screen/pane pan-mark
		]
		show screen
		exit
	]

	either not empty? items [
		if items/1/style = 'panel [
			panel: items/1/pane
			pan: copy panel
			clear panel
			append screen/pane items/1
			remove items
			next-item
			exit
		]
		if items/1/style = 'image [
			append screen/pane items/1
			remove items
		]
		append screen/pane items/1
		remove items
		if empty? items [show-end-mark]
		show screen
	][
		next-page
		show-page build-page
	]
]

back-item: does [
	pan: []
	back-page
	back-flag: true
	show-page build-page
]

;-- Handle Keystrokes:
do-key: func [key] [
	if key = escape [quit]
	switch key [
		#" " [next-item]
		#"^(back)" [back-item]
		down [next-item]
		up [back-item]
		page-down [next-page show-page build-page]
		page-up [back-item]
	]
]

count-slides: has [n d] [
	n: 0
	d: doc-text
	while [d: find/tail d "^/==="] [n: n + 1]
	n
]

this-page: doc ;next-page halt

;-- Build screen and event handler:
screen: [
	size page-size
	across
]

if not author-mode [
	append screen [
		at (as-pair page-size/x - 150 20) t1: txt form now/time
		at (origin) guide
		v1: vh2 "CASPER.r Information and Setup" return  ;; made up this new name 
		vh3 200 "Version:" vh3 gold form system/script/header/version return
		pad 0x30
		vh3 200 "File: " vh3 gold form file return
		vh3 200 "File size:" vh3 gold reform [round (511 + size? system/options/script) / 1024 "K"] return
		vh3 200 "Slides: " vh3 gold form count-slides return
		pad 0x30
		vh3 200 "Page size: " vh3 gold form page-size return
		vh3 200 "Font size: " vh3 gold form text-size return
		vh3 200 "Head font: " vh3 gold form v1/font/name return
		vh3 200 "Body font: " vh3 gold form t1/font/name return
		vh3 200 "Origin: "   vh3 gold form (origin) return
		vh3 200 "Margin: "   vh3 gold form margin return
		vh3 200 "Spacing: "   vh3 gold form spacing return
	]
]

screen: layout/tight screen

screen/image: backdrop
screen/color: navy
view/new screen

insert-event-func func [face event][
	switch event/type [
		key [do-key event/key]
		down [next-item]
		alt-down [back-item]
		close [quit]
	]
	event
]

items: []
if author-mode [show-page build-page]

do-events
